NafParserPy
==========

Description
----------
Parser to parse between KAF and NAF files.

Installation
-----------
Clone the repository from github

````shell
git clone git@github.com:cltl/KafNafParserPy.git
````

Go to the folder just created and install the module (recommend to use virtual environment for python)

````shell
python setup.py install
````

Contact
------

* Ruben Izquierdo Bevia
* ruben.izquierdobevia@vu.nl
* Vrije University of Amsterdam

License
------
Sofware distributed under GPL.v3, see LICENSE file for details.
